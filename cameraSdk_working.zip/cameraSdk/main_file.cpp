
#include <iostream>
#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include "dhnetsdk.h"

#if defined(WIN32) || defined(WIN64)
    #ifdef _DEBUG
        #pragma comment(lib, "dhnetsdk.lib")
    #else
        #pragma comment(lib, "../../Bin/Release(PDB)/dhnetsdk.lib")
    #endif
#elif defined(__linux__)
    #define Sleep(x) usleep(x*1000)
#endif

using namespace std;

void CALLBACK DisConnectFunc(LLONG lLoginID, char *pchDVRIP, LONG nDVRPort, LDWORD dwUser)
{
	printf("Device %s:%d disconnect...\n", pchDVRIP, nDVRPort);
    return;
}

void CALLBACK HaveReConnectFunc(LLONG lLoginID, char *pchDVRIP, LONG nDVRPort, LDWORD dwUser)
{
    return;
}

BOOL CALLBACK MessageCallBack(LONG lCommand, LLONG lLoginID, char *pBuf, DWORD dwBufLen, char *pchDVRIP, LONG nDVRPort, LDWORD dwUser)
{
	if(DH_MOTION_ALARM_EX == lCommand)
	{
		BYTE* pInfo = (BYTE*)pBuf;
		for(unsigned int i = 0; i < dwBufLen; ++i)
		{
			printf("nChannelID = [%2d], state = [%d]\n", i, *(pInfo + i));
		}
	}
	return TRUE;
}

int main()
{
	LLONG            lLoginHandle = 0;
	int              nError       = 0;
	BOOL             bTemp        = FALSE;
	NET_DEVICEINFO   stDevInfo    = {0};
	char             pbuf[1024]    = {0};
	int              nBufLen      = 1024;
	int              pRetLen      = 0;
    int              nChannel     = 0;
    char			szChoose[32] = {0};
    int             i = 0;

	/* init first */
    CLIENT_Init(DisConnectFunc, 0);
	
    /* set reconnect callback function */
    CLIENT_SetAutoReconnect(HaveReConnectFunc, 0);

	//set alarm callback function interface
	CLIENT_SetDVRMessCallBack(MessageCallBack, NULL);

	/* Login */
	memset(&stDevInfo, 0, sizeof(NET_DEVICEINFO));
	printf("=====Please input IP,Port,Username,Password=====\n");
	char szIP[25] = {0};
	int nPort = 0;
	char szUserName[25] = {0};
	char szPwd[25] = {0};
	std::cin >> szIP >> nPort >> szUserName >> szPwd;
	lLoginHandle = CLIENT_Login(szIP, nPort, szUserName, szPwd, &stDevInfo, &nError);
	if (0 == lLoginHandle)
	{
        cout << "Login failed! Press any key to continue..." << endl;
		getchar();
		return -1;
    }

	BOOL bRet = TRUE;
	int nErr = 0;
	DWORD dwReturn = 0;
	int nRetLen = 0;
	Sleep(5);

	cout << "/********* Start Listening *********/" << endl;

	bRet = CLIENT_StartListenEx(lLoginHandle);
	if (TRUE != bRet)
	{
		cout << "Listen failed" << endl;
	}

	while(1)
	{
		Sleep(5);
	}

    /* Logout */
	bTemp = CLIENT_Logout(lLoginHandle);
	if (TRUE != bTemp)
	{
        cout << "Failed to logout! Press any key to continue..." << endl;
		getchar();
		return -2;
    }
	return 0;
}
